import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-survey-analysis',
  templateUrl: './survey-analysis.component.html',
  styleUrls: ['./survey-analysis.component.css']
})
export class SurveyAnalysisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
