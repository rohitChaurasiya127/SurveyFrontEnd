import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-survey-display',
  templateUrl: './survey-display.component.html',
  styleUrls: ['./survey-display.component.css']
})
export class SurveyDisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
