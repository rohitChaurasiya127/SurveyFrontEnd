import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-survey-creation',
  templateUrl: './survey-creation.component.html',
  styleUrls: ['./survey-creation.component.css']
})
export class SurveyCreationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
