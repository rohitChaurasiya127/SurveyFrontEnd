export class survey {
    surveyId : number;
    surveyName : string;
    surveyDesc : string;
    lastEditedBy : number;
    createdDate : string;
    link : any;
}