export class response {
    responseId : number;
    saveUnsave : boolean;
    questionId : number;
    surveyResponseID : number;
}