export class questionOption {
    optionId : number;
    surveyId : number;
    answer : number;
}
