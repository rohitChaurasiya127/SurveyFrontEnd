export class user {
    userId : number;
    emailId : string;
    firstName : string;
    lastName : string;
    password : string;
}