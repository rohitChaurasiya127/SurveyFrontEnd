export class admin {
    adminId : number;
    emailId : string;
    firstName : string;
    lastName : string;
    password : string;
}