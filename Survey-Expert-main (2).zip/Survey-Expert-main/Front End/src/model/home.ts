export class home{
    name : any;
    age: any;

}
