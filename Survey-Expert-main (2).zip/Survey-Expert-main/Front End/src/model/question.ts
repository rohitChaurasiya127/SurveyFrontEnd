export class question{
    questionId : number;
    answerType : string;
    questionText : string;
    surveyId : number;
}