export class surveyResponse {
    surveyResponseID : number;
    surveyId : number;
    userID : number;
} 