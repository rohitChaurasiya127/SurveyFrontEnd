export class responseOption {
    optionId : number;
    answer : string;
    responseId : number;
}